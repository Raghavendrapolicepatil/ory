// ======================================
// Snackible Products Loader
// ======================================
let allProducts = [];

async function loadProducts() {

    try {

        
        const response = await fetch("http://localhost:5000/api/products");

        allProducts = await response.json();

const products = allProducts;

// ======================================
// Today's Deals
// ======================================

const todaysDeals = products.filter(

    product =>

        product.todayDeal === true &&

        product.stock > 0

);

const dealsContainer =

    document.getElementById("todays-deals");

if(dealsContainer){

    dealsContainer.innerHTML = "";

}

function createProductCard(product){

    return `

    <div class="product-card">

        <span class="discount">

            ${product.discount || "0% OFF"}

        </span>

        <button

            class="wishlist-btn"

            onclick='toggleWishlist({

                id:${product.id},

                name:${JSON.stringify(product.name)},

                price:${product.price},

                image:${JSON.stringify(product.image)},

                weight:${JSON.stringify(product.weight)}

            },this)'>

            <i class="${

                isWishlisted(product.id)

                ?

                "ri-heart-fill"

                :

                "ri-heart-line"

            }"

            style="${

                isWishlisted(product.id)

                ?

                "color:#ff3b5c;"

                :

                ""

            }">

            </i>

        </button>

        <img

            loading="lazy"

            src="${product.image}"

            alt="${product.name}"

            onclick="window.location='product-details.html?id=${product.id}'">

        <h4

            onclick="window.location='product-details.html?id=${product.id}'">

            ${product.name}

        </h4>

        <div class="weight-chip">

            ${product.weight}

        </div>

        <div class="price-box">

            <span class="price">

                ₹${product.price}

            </span>

            <span class="old-price">

                ₹${product.mrp}

            </span>

        </div>

        <div class="product-bottom">

            ${

                product.stock <= 0

                ?

                `<button class="out-stock-btn" disabled>

                    Out of Stock

                </button>`

                :

                `<div id="cart-${product.id}">

                    ${renderCartButton(product)}

                </div>`

            }

        </div>

    </div>

    `;

}

    // ======================================
// Today's Deals
// ======================================

todaysDeals.forEach(product => {

    if (dealsContainer) {

        dealsContainer.innerHTML += createProductCard(product);

    }

});

// ======================================
// Category Products
// ======================================

products.forEach(product => {

    const container = document.getElementById(product.category);

    if (!container) return;

    container.innerHTML += createProductCard(product);

});

// Animate Cards

animateCards();
    }

    catch(error){

        console.error(error);

    }

}

// ======================================
// Premium Cart Button
// ======================================

function renderCartButton(product){

    const qty = getProductQty(product.id);

    // ADD BUTTON

    if(qty===0){

        return `

        <button

            class="add-btn"

            onclick="addProduct(

                ${product.id},

                '${product.name.replace(/'/g,"\\'")}',

                ${product.price},

                '${product.image}'

            )">

            <i class="ri-add-line"></i>

<i class="ri-add-line"></i>

        </button>

        `;

    }

    // QUANTITY

    return `

    <div class="quantity-control">

        <button

            class="qty-minus"

            onclick="minusProduct(${product.id})">

            <i class="ri-subtract-line"></i>

        </button>

        <span>

            ${qty}

        </span>

        <button

            class="qty-plus"

            onclick="plusProduct(${product.id})">

            <i class="ri-add-line"></i>

        </button>

    </div>

    `;

}

// ======================================
// Add Product
// ======================================

function addProduct(id, name, price, image) {

    addToCart(id, name, price, image);

    refreshProduct(id);

}

// ======================================
// Increase Qty
// ======================================

function plusProduct(id) {

    increaseQty(id);

    refreshProduct(id);

}

// ======================================
// Decrease Qty
// ======================================

function minusProduct(id) {

    decreaseQty(id);

    refreshProduct(id);

}

// ======================================
// Refresh Product
// ======================================

function refreshProduct(id) {

    const product = document.getElementById("cart-" + id);

    if (!product) return;

    const cart =
        JSON.parse(localStorage.getItem("cart")) || [];

    const item =
        cart.find(p => p.id === id);

    const qty =
        item ? item.qty : 0;

    if (qty === 0) {

        product.innerHTML = `

        <button

            class="add-btn"

            onclick="addProduct(

                ${id},

                '${allProducts.find(p=>p.id===id)?.name.replace(/'/g,"\\'")}',

                ${allProducts.find(p=>p.id===id)?.price},

                '${allProducts.find(p=>p.id===id)?.image}'

            )">

            <i class="ri-add-line"></i>

            <span>Add</span>

        </button>

        `;

    }

    else {

        product.innerHTML = `

        <div class="quantity-control">

            <button

                class="qty-minus"

                onclick="minusProduct(${id})">

                <i class="ri-subtract-line"></i>

            </button>

            <span>${qty}</span>

            <button

                class="qty-plus"

                onclick="plusProduct(${id})">

                <i class="ri-add-line"></i>

            </button>

        </div>

        `;

    }

}

// ======================================
// Card Animation
// ======================================

function animateCards(){

    const cards =

    document.querySelectorAll(".product-card");

    cards.forEach((card,index)=>{

        card.style.opacity="0";

        card.style.transform="translateY(20px)";

        setTimeout(()=>{

            card.style.transition=

            ".35s ease";

            card.style.opacity="1";

            card.style.transform="translateY(0)";

        },index*25);

    });

}

// ======================================
// Lazy Images
// ======================================

window.addEventListener("load",()=>{

    animateCards();

});

// ======================================
// Smooth Wishlist
// ======================================

document.addEventListener("click",(e)=>{

    const btn=e.target.closest(".wishlist-btn");

    if(!btn) return;

    btn.animate([

        {

            transform:"scale(.8)"

        },

        {

            transform:"scale(1.15)"

        },

        {

            transform:"scale(1)"

        }

    ],{

        duration:180

    });

});

// ======================================
// Add Button Ripple
// ======================================

document.addEventListener("click",(e)=>{

    const btn=e.target.closest(".add-btn");

    if(!btn) return;

    btn.animate([

        {

            transform:"scale(.95)"

        },

        {

            transform:"scale(1.05)"

        },

        {

            transform:"scale(1)"

        }

    ],{

        duration:180

    });

});





// ======================================
// Start
// ======================================

loadProducts();